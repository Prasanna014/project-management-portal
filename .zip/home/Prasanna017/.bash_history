sudpo su -
sudo su -
